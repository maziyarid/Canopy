Canopy — Mangools × Google Sheets
Author: MAZ//ID (Maziyar)
Brand: MΛZ

Install
1. New Google Sheet → Extensions → Apps Script
2. Paste Code.gs (replace the stub)
3. Project Settings → Show appsscript.json → paste the manifest
4. Save, reload the sheet, open Canopy → Setup workbook
5. Canopy → Save API key (mangools.com/api-token)

Agents
Deploy → New deployment → Web app.
POST JSON { secret, action, payload } with WEBHOOK_SECRET from Settings.

Actions: quota | read | write | related | bulk | competitor | gap | track | agent | setting

M•Z
